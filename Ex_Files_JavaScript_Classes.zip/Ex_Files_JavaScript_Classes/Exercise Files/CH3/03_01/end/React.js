import React, { Component } from 'react';

class Button extends Component {
    render() {
        return ( <button>Hello</button> )
    }
}

export default Button;